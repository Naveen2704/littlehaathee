import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-artist-popup',
  templateUrl: './artist-popup.component.html',
  styleUrls: ['./artist-popup.component.scss'],
})
export class ArtistPopupComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
