/* eslint-disable @typescript-eslint/dot-notation */
/* eslint-disable no-trailing-spaces */
/* eslint-disable max-len */
/* eslint-disable @typescript-eslint/naming-convention */
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoadingController, ModalController, ToastController } from '@ionic/angular';
import { GlobalService } from 'src/app/global.service';
import { ArtistsComponent } from '../artists/artists.component';
import { pro_imagesUrl } from '../../../environments/environment';
import Swal from 'sweetalert2';
 
@Component({
  selector: 'app-single',
  templateUrl: './single.component.html',
  styleUrls: ['./single.component.scss'],
})
export class SingleComponent implements OnInit {
    Cat_id: number;
    proList: any;
    artist: any;
    imageUrl: any = pro_imagesUrl;
    featuredImage: any;
    relatedList: any;
    additional_images: any = [];

  constructor(private route: ActivatedRoute, private service: GlobalService, private toast: ToastController, private router: Router, private loader: LoadingController) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
        this.Cat_id = params['id'];
    });
    this.singlePro(this.Cat_id);
  }

  openPro(product_id){
    this.router.navigateByUrl('/single/' + product_id);
  }

  artistInfo(artist_id){
    this.service.getArtistInfo(artist_id).subscribe((data: any) => {
        if(data.code === '200'){
            this.artist = data.result.info;
            console.log(this.artist);
        }
    });
  }


  Catproducts(catid: number){
    this.service.catProducts(catid).subscribe((data: any) => {

        this.relatedList = data.result.productList;
        console.log(this.proList);
    });
}
  singlePro(catid: number){
      this.service.getSinglePro(catid).subscribe((data: any) => {
          this.proList = data.result.productList;
          this.featuredImage = this.proList[0].product_image;
          this.additional_images = this.proList[0].additional_images;
          this.artistInfo(this.proList[0].artist_id);
          this.Catproducts(this.proList[0].category_id);
      });
  }

  changeImg(img){
      this.featuredImage = img;
  }

  colorImages(product_id, color){
      this.service.getColorImages(product_id, color.substring(1)).subscribe((data: any) => {
        if(data.code === '200'){
            this.featuredImage = data.result.list[0].featured_image;
            this.additional_images = data.result.list[0].additional_images;
        }
      });
  }

  async cart(pro_id, stock_id){
    const loading = await this.loader.create({
        cssClass: 'my-custom-class',
        message: 'Adding to Cart',
        // duration: 2000
      });
      await loading.present();
    this.service.addToCart(pro_id, stock_id).subscribe((data: any) => {
        if(data.code === '200'){
            Swal.fire({
                title: 'Cart',
                html: 'Item Added Successfully!',
                showConfirmButton: false,
                icon: 'success',
                iconColor: '#0f0',
                timer: 2000,
                timerProgressBar: true  
            }).then((result) => {
              result.dismiss;
          });
          loading.dismiss();
        }
    });
  }

}
