import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { GlobalService } from 'src/app/global.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-place-order',
  templateUrl: './place-order.component.html',
  styleUrls: ['./place-order.component.scss'],
})
export class PlaceOrderComponent implements OnInit {

    addList: any = [];
    addForm: FormGroup;
    address_flag: any = 'false';
  constructor(private service: GlobalService, private form: FormBuilder, private router: Router, private toast: ToastController) {
      this.addForm = this.form.group({
          name: ['', Validators.required],
          mobile: ['', Validators.required],
          address: ['', Validators.required],
          city: ['', Validators.required],
          state:['', Validators.required],
          pincode: ['', Validators.required]
      })
   }

  ngOnInit() {
      console.log(this.address_flag);
      this.address();
  }

  address(){
      this.service.addressList().subscribe((data: any) => {
        if(data.code === '200'){
            this.addList = data.result.list;
        }
      });
  }

  deliverHere(address_id){
    this.service.deliver(address_id).subscribe(async (data: any) => {
        if(data.code === '200'){
            Swal.fire({
              title: 'Success',
              html: 'Order Placed Successfully',
              icon: 'success',
              iconColor: '#0f0',
              showConfirmButton: false,
              timer: 2000,
              timerProgressBar: true
            })
            this.router.navigate(['/confirm-order']);
        }
    });
  }

  saveAddress(){
      if(this.addForm.invalid){
          return;
      }
      this.service.addAddress(this.addForm.value).subscribe(async (data: any) => {
        if(data.code === '200'){
            this.address();
            Swal.fire({
              title: 'Success',
              html: 'Order Placed Successfully',
              icon: 'success',
              iconColor: '#0f0',
              showConfirmButton: false,
              timer: 2000,
              timerProgressBar: true
            })
            this.router.navigate(['/confirm-order']);
        }
      });
  }

}
