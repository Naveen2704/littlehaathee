import { Component, OnInit } from '@angular/core';
import { Form, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { GlobalService } from 'src/app/global.service';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
})
export class RegisterComponent implements OnInit {

    registerForm: FormGroup;
    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    // verticalPosition: MatSnackBarVerticalPosition = 'bottom';

  constructor(private service: GlobalService, private form: FormBuilder, private toast: ToastController, private route: Router) {
        this.registerForm = this.form.group({
            name: ['', Validators.required],
            mobile: ['', Validators.required],
            email: ['', Validators.required],
            password: ['', Validators.required]
        });
   }

  ngOnInit() {}

  async registerUser(){
      if(this.registerForm.invalid){
        const alrt = await this.toast.create({
            message: 'Please fill all fields',
            position: 'bottom',
            duration: 3000,
            cssClass: ['toast-class','danger-toast']
        });
        alrt.present();
          return;
      }
      this.service.register(this.registerForm.value).subscribe(async (data: any) => {
        if(data.code === '200'){
            const alrt = await this.toast.create({
                message: 'Account Created Successfully!',
                position: 'bottom',
                duration: 3000,
                cssClass: ['toast-class','success-toast']
            });
            alrt.present();
            this.route.navigate(['/auth']);
        }
      });
  }


}
