export const environment = {
  production: true
};

// export const url = 'http://localhost:8080/littlehathee/API/FrontFrames/';
// export const pro_imagesUrl = 'http://localhost:8080/littlehathee/uploads/products/';
export const pro_imagesUrl = 'https://littlehaathee.com/admin@2021/uploads/products/';
export const url = 'https://littlehaathee.com/admin@2021/API/FrontFrames/';